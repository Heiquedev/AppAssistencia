package View;

import java.awt.Desktop;
import java.net.URI;
import javax.swing.JLabel;

public class TelaInfoDev extends javax.swing.JFrame {

    /**
     * Creates new form TelaInfoDev
     */
    public TelaInfoDev() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlBase = new javax.swing.JPanel();
        pnlRight = new javax.swing.JPanel();
        pnlTop = new javax.swing.JPanel();
        lblTítulo = new javax.swing.JLabel();
        pnlLeft = new javax.swing.JPanel();
        pnlBottom = new javax.swing.JPanel();
        pnlBotoes = new javax.swing.JPanel();
        btnVoltar = new javax.swing.JButton();
        pnlCenter = new javax.swing.JPanel();
        lblTelefone = new javax.swing.JLabel();
        lblNúmero = new javax.swing.JLabel();
        lblDatatxt = new javax.swing.JLabel();
        lblDataDados = new javax.swing.JLabel();
        lblInstituicao = new javax.swing.JLabel();
        lblNomeInst = new javax.swing.JLabel();
        lblFotoDePerfil = new javax.swing.JLabel();
        lblNomeCompleto = new javax.swing.JLabel();
        lblIdade = new javax.swing.JLabel();
        lblOrientador = new javax.swing.JLabel();
        lblRedesSociais = new javax.swing.JLabel();
        lblTikTok = new javax.swing.JLabel();
        lblInstagram = new javax.swing.JLabel();
        lblGitHub = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setResizable(false);

        pnlBase.setLayout(new java.awt.BorderLayout());

        javax.swing.GroupLayout pnlRightLayout = new javax.swing.GroupLayout(pnlRight);
        pnlRight.setLayout(pnlRightLayout);
        pnlRightLayout.setHorizontalGroup(
            pnlRightLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );
        pnlRightLayout.setVerticalGroup(
            pnlRightLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 338, Short.MAX_VALUE)
        );

        pnlBase.add(pnlRight, java.awt.BorderLayout.LINE_END);

        lblTítulo.setFont(new java.awt.Font("Segoe UI", 3, 15)); // NOI18N
        lblTítulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTítulo.setText("APP/SISTEMA DE ASSITÊNCIA ");

        javax.swing.GroupLayout pnlTopLayout = new javax.swing.GroupLayout(pnlTop);
        pnlTop.setLayout(pnlTopLayout);
        pnlTopLayout.setHorizontalGroup(
            pnlTopLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlTopLayout.createSequentialGroup()
                .addContainerGap(25, Short.MAX_VALUE)
                .addComponent(lblTítulo, javax.swing.GroupLayout.PREFERRED_SIZE, 620, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(43, 43, 43))
        );
        pnlTopLayout.setVerticalGroup(
            pnlTopLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTopLayout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(lblTítulo)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        pnlBase.add(pnlTop, java.awt.BorderLayout.PAGE_START);

        javax.swing.GroupLayout pnlLeftLayout = new javax.swing.GroupLayout(pnlLeft);
        pnlLeft.setLayout(pnlLeftLayout);
        pnlLeftLayout.setHorizontalGroup(
            pnlLeftLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );
        pnlLeftLayout.setVerticalGroup(
            pnlLeftLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 338, Short.MAX_VALUE)
        );

        pnlBase.add(pnlLeft, java.awt.BorderLayout.LINE_START);

        btnVoltar.setFont(new java.awt.Font("Segoe UI", 2, 16)); // NOI18N
        btnVoltar.setText("Voltar");
        btnVoltar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVoltarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pnlBotoesLayout = new javax.swing.GroupLayout(pnlBotoes);
        pnlBotoes.setLayout(pnlBotoesLayout);
        pnlBotoesLayout.setHorizontalGroup(
            pnlBotoesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlBotoesLayout.createSequentialGroup()
                .addContainerGap(133, Short.MAX_VALUE)
                .addComponent(btnVoltar, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        pnlBotoesLayout.setVerticalGroup(
            pnlBotoesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlBotoesLayout.createSequentialGroup()
                .addContainerGap(12, Short.MAX_VALUE)
                .addComponent(btnVoltar)
                .addContainerGap())
        );

        javax.swing.GroupLayout pnlBottomLayout = new javax.swing.GroupLayout(pnlBottom);
        pnlBottom.setLayout(pnlBottomLayout);
        pnlBottomLayout.setHorizontalGroup(
            pnlBottomLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlBottomLayout.createSequentialGroup()
                .addContainerGap(406, Short.MAX_VALUE)
                .addComponent(pnlBotoes, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        pnlBottomLayout.setVerticalGroup(
            pnlBottomLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlBottomLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(pnlBotoes, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pnlBase.add(pnlBottom, java.awt.BorderLayout.PAGE_END);

        pnlCenter.setForeground(new java.awt.Color(0, 51, 255));

        lblTelefone.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        lblTelefone.setText("Telefone:");

        lblNúmero.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblNúmero.setForeground(new java.awt.Color(0, 153, 255));
        lblNúmero.setText("+55 (51) 99803-1309");

        lblDatatxt.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        lblDatatxt.setText("Começo e Término:");

        lblDataDados.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        lblDataDados.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblDataDados.setText("Começo de 09/24 - 19/11/24.  ");

        lblInstituicao.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        lblInstituicao.setText("Instituição:");

        lblNomeInst.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        lblNomeInst.setText("Senac de São Leopoldo.");

        lblFotoDePerfil.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagens/GutsIcon.png"))); // NOI18N

        lblNomeCompleto.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        lblNomeCompleto.setText("Nome do Dev: Heique Rodrigues Fuck.  ");

        lblIdade.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        lblIdade.setText("Idade: 17 anos.");

        lblOrientador.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        lblOrientador.setText("Orientador na Linguagem Java: Celso Teixeira.");

        lblRedesSociais.setFont(new java.awt.Font("Segoe UI", 1, 13)); // NOI18N
        lblRedesSociais.setText("         Redes Sociais:");

        lblTikTok.setBackground(new java.awt.Color(255, 255, 255));
        lblTikTok.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblTikTok.setForeground(new java.awt.Color(0, 153, 255));
        lblTikTok.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTikTok.setText("TikTok: @heique_fuck");
        lblTikTok.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblTikTokMouseClicked(evt);
            }
        });

        lblInstagram.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblInstagram.setForeground(new java.awt.Color(0, 153, 255));
        lblInstagram.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblInstagram.setText("Instagram: @heiquefr");
        lblInstagram.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblInstagramMouseClicked(evt);
            }
        });

        lblGitHub.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblGitHub.setForeground(new java.awt.Color(0, 153, 255));
        lblGitHub.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblGitHub.setText("GitHub: Heiquedev");
        lblGitHub.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblGitHubMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout pnlCenterLayout = new javax.swing.GroupLayout(pnlCenter);
        pnlCenter.setLayout(pnlCenterLayout);
        pnlCenterLayout.setHorizontalGroup(
            pnlCenterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCenterLayout.createSequentialGroup()
                .addGroup(pnlCenterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblRedesSociais, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlCenterLayout.createSequentialGroup()
                        .addGap(37, 37, 37)
                        .addGroup(pnlCenterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnlCenterLayout.createSequentialGroup()
                                .addComponent(lblGitHub, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(lblInstagram, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblTikTok, javax.swing.GroupLayout.PREFERRED_SIZE, 208, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(pnlCenterLayout.createSequentialGroup()
                                .addComponent(lblFotoDePerfil)
                                .addGap(40, 40, 40)
                                .addGroup(pnlCenterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(lblIdade)
                                    .addComponent(lblNomeCompleto, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(lblOrientador)
                                    .addGroup(pnlCenterLayout.createSequentialGroup()
                                        .addComponent(lblInstituicao)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(lblNomeInst))))
                            .addGroup(pnlCenterLayout.createSequentialGroup()
                                .addGap(50, 50, 50)
                                .addComponent(lblNúmero)
                                .addGap(105, 105, 105)
                                .addComponent(lblDataDados))
                            .addGroup(pnlCenterLayout.createSequentialGroup()
                                .addComponent(lblTelefone)
                                .addGap(204, 204, 204)
                                .addComponent(lblDatatxt)))))
                .addContainerGap())
        );
        pnlCenterLayout.setVerticalGroup(
            pnlCenterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlCenterLayout.createSequentialGroup()
                .addGroup(pnlCenterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlCenterLayout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addComponent(lblNomeCompleto)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblIdade)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(pnlCenterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblInstituicao)
                            .addComponent(lblNomeInst))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblOrientador)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(pnlCenterLayout.createSequentialGroup()
                        .addContainerGap(22, Short.MAX_VALUE)
                        .addComponent(lblFotoDePerfil)
                        .addGap(24, 24, 24)))
                .addGroup(pnlCenterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblTelefone)
                    .addComponent(lblDatatxt))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlCenterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblDataDados)
                    .addComponent(lblNúmero))
                .addGap(18, 18, 18)
                .addComponent(lblRedesSociais)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pnlCenterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblTikTok)
                    .addComponent(lblGitHub)
                    .addComponent(lblInstagram))
                .addContainerGap(30, Short.MAX_VALUE))
        );

        pnlBase.add(pnlCenter, java.awt.BorderLayout.CENTER);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(pnlBase, javax.swing.GroupLayout.DEFAULT_SIZE, 688, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(pnlBase, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnVoltarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVoltarActionPerformed
        this.dispose();
    }//GEN-LAST:event_btnVoltarActionPerformed


    private void lblGitHubMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblGitHubMouseClicked
        try {
            URI link = new URI("https://github.com/Heiquedev");
            Desktop.getDesktop().browse(link);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_lblGitHubMouseClicked

    private void lblInstagramMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblInstagramMouseClicked
        try {
            URI link = new URI("https://www.instagram.com/heiquefr/?__d=1");
            Desktop.getDesktop().browse(link);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_lblInstagramMouseClicked

    private void lblTikTokMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblTikTokMouseClicked
        try {
            URI link = new URI("https://www.tiktok.com/@heique_fuck");
            Desktop.getDesktop().browse(link);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_lblTikTokMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaInfoDev.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaInfoDev.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaInfoDev.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaInfoDev.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaInfoDev().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnVoltar;
    private javax.swing.JLabel lblDataDados;
    private javax.swing.JLabel lblDatatxt;
    private javax.swing.JLabel lblFotoDePerfil;
    private javax.swing.JLabel lblGitHub;
    private javax.swing.JLabel lblIdade;
    private javax.swing.JLabel lblInstagram;
    private javax.swing.JLabel lblInstituicao;
    private javax.swing.JLabel lblNomeCompleto;
    private javax.swing.JLabel lblNomeInst;
    private javax.swing.JLabel lblNúmero;
    private javax.swing.JLabel lblOrientador;
    private javax.swing.JLabel lblRedesSociais;
    private javax.swing.JLabel lblTelefone;
    private javax.swing.JLabel lblTikTok;
    private javax.swing.JLabel lblTítulo;
    private javax.swing.JPanel pnlBase;
    private javax.swing.JPanel pnlBotoes;
    private javax.swing.JPanel pnlBottom;
    private javax.swing.JPanel pnlCenter;
    private javax.swing.JPanel pnlLeft;
    private javax.swing.JPanel pnlRight;
    private javax.swing.JPanel pnlTop;
    // End of variables declaration//GEN-END:variables
}
