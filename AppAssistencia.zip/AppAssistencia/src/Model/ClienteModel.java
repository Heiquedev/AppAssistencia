package Model;

import DAL.OperAtualizaDadosClienteBD;
import DAL.OperExcluiDadosClienteBD;
import DAL.OperFiltroDadosCliente;
import DAL.OperInsereRegistroClienteBD;
import DAL.OperListarDadosClienteBD;
import DAL.OperRecuperaClienteBD;
import java.util.ArrayList;

public class ClienteModel extends LoginModel {

    private String id;
    private String nome;
    private String CEP;
    private String endereco;
    private String fone;
    private String email;

    public ClienteModel() {
    }

    public ClienteModel(String id, String nome, String CEP, String endereco, String fone, String email) {
        this.id = id;
        this.nome = nome;
        this.CEP = CEP;
        this.endereco = endereco;
        this.fone = fone;
        this.email = email;
    }

    public ClienteModel(String nome, String CEP, String endereco, String fone, String email) {
        this.nome = nome;
        this.CEP = CEP;
        this.endereco = endereco;
        this.fone = fone;
        this.email = email;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCEP() {
        return CEP;
    }

    public void setCEP(String CEP) {
        this.CEP = CEP;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getFone() {
        return fone;
    }

    public void setFone(String fone) {
        this.fone = fone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    
    public ArrayList<ClienteModel> listarRegistrosClienteModel(){
        OperListarDadosClienteBD op = new OperListarDadosClienteBD();
        return op.listarRegistrosClienteBD();
    }

    public ArrayList<ClienteModel>filtrarRegistrosClienteModel(String nome) {
        OperFiltroDadosCliente op = new OperFiltroDadosCliente();
        return op.filtrarRegistrosBD(nome);
    }

    public void excluirRegistrosClienteModel(String idCliente) {
        OperExcluiDadosClienteBD op = new OperExcluiDadosClienteBD();
        op.excluirRegistroCliente(idCliente);
    }

    public void atualizarRegistrosClienteModel(ClienteModel clienteAtualizado) {
        OperAtualizaDadosClienteBD op = new OperAtualizaDadosClienteBD();
        op.atualizarRegistroCliente(clienteAtualizado);

    }

    public void inserirRegistrosClienteModel(ClienteModel novoCliente) {
        OperInsereRegistroClienteBD op = new OperInsereRegistroClienteBD();
        op.inserirRegistro(novoCliente);
    }

    public ClienteModel recuperarClienteModel(String idCliente) {
        OperRecuperaClienteBD op = new OperRecuperaClienteBD();
        return op.recuperarCliente(idCliente);
    }
    
}
