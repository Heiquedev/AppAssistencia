package Model;

import DAL.OperConcluiOuAtualizaOS;
import DAL.OperCriarOrderService;
import DAL.OperListarRegistrosEquipBD;
import DAL.OperRecuperaClienteBD;
import java.util.ArrayList;

public class EquipamentoModel {

    private String id;
    private String equipamento;
    private String defeito;
    private String servico;
    private String tecnico;
    private String valor;
    private String id_cliente;
    private String status;

    public EquipamentoModel() {
    }

    public EquipamentoModel(String id, String equipamento, String defeito, String servico, String tecnico, String valor, String id_cliente, String status) {
        this.id = id;
        this.equipamento = equipamento;
        this.defeito = defeito;
        this.servico = servico;
        this.tecnico = tecnico;
        this.valor = valor;
        this.id_cliente = id_cliente;
        this.status = status;
    }

    public EquipamentoModel(String id, String equipamento, String defeito, String servico, String tecnico, String valor, String id_cliente) {
        this.id = id;
        this.equipamento = equipamento;
        this.defeito = defeito;
        this.servico = servico;
        this.tecnico = tecnico;
        this.valor = valor;
        this.id_cliente = id_cliente;
    }

    public EquipamentoModel(String equipamento, String defeito, String servico, String tecnico, String valor, String id_cliente) {
        this.equipamento = equipamento;
        this.defeito = defeito;
        this.servico = servico;
        this.tecnico = tecnico;
        this.valor = valor;
        this.id_cliente = id_cliente;
    }

    public EquipamentoModel(String equipamento, String defeito, String id_cliente, String status) {
        this.equipamento = equipamento;
        this.defeito = defeito;
        this.id_cliente = id_cliente;
        this.status = status;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getEquipamento() {
        return equipamento;
    }

    public void setEquipamento(String equipamento) {
        this.equipamento = equipamento;
    }

    public String getDefeito() {
        return defeito;
    }

    public void setDefeito(String defeito) {
        this.defeito = defeito;
    }

    public String getServico() {
        return servico;
    }

    public void setServico(String servico) {
        this.servico = servico;
    }

    public String getTecnico() {
        return tecnico;
    }

    public void setTecnico(String tecnico) {
        this.tecnico = tecnico;
    }

    public String getValor() {
        return valor;
    }

    public void setValor(String valor) {
        this.valor = valor;
    }

    public String getId_cliente() {
        return id_cliente;
    }

    public void setId_cliente(String id_cliente) {
        this.id_cliente = id_cliente;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void inserirEquipamento(EquipamentoModel novoEquip) {
        OperCriarOrderService op = new OperCriarOrderService();
        op.inserirRegistroEquipamento(novoEquip);
    }

    public ArrayList<EquipamentoModel> listaRegistroEquipamentosModel() {
        OperListarRegistrosEquipBD op = new OperListarRegistrosEquipBD();
        return op.listarRegistrosEquipBD();

    }

    public void atualizarRegistrosOSModel(EquipamentoModel equipAtualizado) {
        OperConcluiOuAtualizaOS op = new OperConcluiOuAtualizaOS();
        op.atualizarOrdemServ(equipAtualizado);

    }

}
