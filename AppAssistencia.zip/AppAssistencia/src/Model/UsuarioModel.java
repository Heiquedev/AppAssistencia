package Model;

import DAL.OperAtualizaDadosBD;
import DAL.OperExcluiDadosBD;
import DAL.OperFiltroDadosBD;
import DAL.OperInsereRegistroBD;
import DAL.OperListaDadosBD;
import DAL.OperRecuperaUsuarioBD;
import DAL.OperReseteSenhaDadosBD;
import java.util.ArrayList;

public class UsuarioModel extends LoginModel {

    //Atributos que definem o cadastro de um usuário
    private String id;
    private String userName;
    private String email;
    private String perfil;

    // Métodos Contrutores - vazio
    public UsuarioModel() {
    }

    //Construtor utilizado para listagem de dados contidos no banco
    public UsuarioModel(String id, String userName, String email, String login, String password, String perfil) {
        super(login, password);
        this.id = id;
        this.userName = userName;
        this.email = email;
        this.perfil = perfil;
    }

    //Construtor utilizado para inserir novo registro no banco de dados
    public UsuarioModel(String userName, String email, String login, String password, String perfil) {
        super(login, password);
        this.userName = userName;
        this.email = email;
        this.perfil = perfil;
    }

    // Getters e Setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getE_mail() {
        return email;
    }

    public void setE_mail(String email) {
        this.email = email;
    }

    public String getPerfil() {
        return perfil;
    }

    public void setPerfil(String perfil) {
        this.perfil = perfil;
    }

    //Listagem de todos os dados
    public ArrayList<UsuarioModel> listarRegistrosModel() {
        OperListaDadosBD op = new OperListaDadosBD();
        return op.listarRegistrosBD();
    }

    //Filtragem de dados
    public ArrayList<UsuarioModel> filtrarRegistrosModel(String id) {
        OperFiltroDadosBD op = new OperFiltroDadosBD();
        return op.filtrarRegistrosBD(id);
    }

    //Inserção de um novo registro no banco de dados // Model
    public void inserirRegistrosModel(UsuarioModel novoUsuario) {
        OperInsereRegistroBD op = new OperInsereRegistroBD();
        op.inserirRegistro(novoUsuario);
    }

    //Envio da informação para o DAL para exclusão de registro
    public void excluirRegistrosModel(String idUser) {
        OperExcluiDadosBD op = new OperExcluiDadosBD();
        op.excluirRegistro(idUser);
    }

    //Método que obtenha as informações atualizadas (UPDATE), por fim, manda ao Banco de dados
    public void atualizarRegistrosModel(UsuarioModel usuarioAtualizado) {
        OperAtualizaDadosBD op = new OperAtualizaDadosBD();
        op.atualizarRegistro(usuarioAtualizado);

    }

    public void atualizarSenhaUserModel(UsuarioModel usuarioSenhaAtualizada) {
        OperReseteSenhaDadosBD op = new OperReseteSenhaDadosBD();
        op.resetarSenha(usuarioSenhaAtualizada);
    }
    public UsuarioModel recuperarUsuarioModel(String idUser){
        OperRecuperaUsuarioBD op = new OperRecuperaUsuarioBD();
        return op.recuperarUsuario(idUser);
    }

}
