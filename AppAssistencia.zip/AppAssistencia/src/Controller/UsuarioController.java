package Controller;

import Model.UsuarioModel;
import java.util.ArrayList;

public class UsuarioController {

    public ArrayList<UsuarioModel> listarRegistrosController() {
        UsuarioModel op = new UsuarioModel();
        return op.listarRegistrosModel();
    }

    public ArrayList<UsuarioModel> filtrarRegistrosController(String id) {
        UsuarioModel op = new UsuarioModel();
        return op.filtrarRegistrosModel(id);
    }

    //Método que vai enviar as informações recebidas
    // da tela de interface gráfica para o método de inserir
    // registro contido no model.
    public void inserirRegistroController(String userName, String email, String login, String password, String perfil) {
        UsuarioModel novoUsuario = new UsuarioModel(userName, email, login, password, perfil);
        novoUsuario.inserirRegistrosModel(novoUsuario);
    }

    //Método no controller que obtenha a informação do ID para a exclusão
    public void excluirRegistroController(String idUser) {
        UsuarioModel op = new UsuarioModel();
        op.excluirRegistrosModel(idUser);
    }

    //Atualização de Registro 
    public void atualizarRegistroController(String idUser, String userName, String email, String login, String perfil) {
        UsuarioModel usuarioAtualizado = new UsuarioModel(idUser, userName, email, login, null, perfil);
        usuarioAtualizado.atualizarRegistrosModel(usuarioAtualizado);

    }

    public void resetarSenhaController(String id, String userName, String email, String login, String password, String perfil) {
        UsuarioModel usuarioSenhaAtualizada = new UsuarioModel(id, userName, email, login, password, perfil);
        usuarioSenhaAtualizada.atualizarSenhaUserModel(usuarioSenhaAtualizada);
    }

    public UsuarioModel recuperarUsuarioController(String idUser) {
        UsuarioModel usuarioRecuperado = new UsuarioModel();
        return usuarioRecuperado.recuperarUsuarioModel(idUser);

    }

    public void resetarSenhaController() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
