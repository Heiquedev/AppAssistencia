package Controller;

import Model.EquipamentoModel;
import java.util.ArrayList;

public class EquipamentoController {

    public void inserirRegistroEquipamentoController(String equipamento, String defeito, String idCliente, String status) {
        EquipamentoModel novoEquip = new EquipamentoModel(equipamento, defeito, idCliente, "Espera");
        novoEquip.inserirEquipamento(novoEquip);
    }

    public ArrayList<EquipamentoModel> listarRegistrosEquipController() {
        EquipamentoModel op = new EquipamentoModel();
        return op.listaRegistroEquipamentosModel();
    }

    public void atualizarRegistroOSController(String id_equip, String equipamento, String defeito, String servico, String tecnico, String valor, String idCliente, String status) {
        EquipamentoModel equipAtualizado = new EquipamentoModel(id_equip, equipamento, defeito, servico, tecnico, valor, idCliente, status);
        equipAtualizado.atualizarRegistrosOSModel(equipAtualizado);

    }
}
