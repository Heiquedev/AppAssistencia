package Controller;

import Model.UsuarioModel;
import Model.ClienteModel;
import java.util.ArrayList;

public class ClienteController {

    public ArrayList<ClienteModel>listarRegistrosClienteController() {
        ClienteModel op = new ClienteModel();
        return op.listarRegistrosClienteModel();
    }
    public ArrayList<ClienteModel> filtrarRegistrosClienteController(String nome) {
        ClienteModel op = new ClienteModel();
        return op.filtrarRegistrosClienteModel(nome);
    }

    //Método que vai enviar as informações recebidas
    // da tela de interface gráfica para o método de inserir
    // registro contido no model.
    public void inserirRegistroClienteController(String nome, String cep, String endereco, String fone, String email) {
        ClienteModel novoCliente = new ClienteModel(nome, cep, endereco, fone, email);
        novoCliente.inserirRegistrosClienteModel(novoCliente);
    }

    //Método no controller que obtenha a informação do ID para a exclusão
    public void excluirRegistroClienteController(String idUser) {
        ClienteModel op = new ClienteModel();
        op.excluirRegistrosClienteModel(idUser);
    }

    //Atualização de Registro 
    public void atualizarRegistroClienteController(String id ,String nomeCliente, String CEP,String endereco, String fone, String email) {
        ClienteModel clienteAtualizado = new ClienteModel(id, nomeCliente, CEP, endereco, fone, email);
        clienteAtualizado.atualizarRegistrosClienteModel(clienteAtualizado);

    }

    public ClienteModel recuperarClienteController(String idCliente) {
        ClienteModel clienteRecuperado = new ClienteModel();
        return clienteRecuperado.recuperarClienteModel(idCliente);

    }

}
