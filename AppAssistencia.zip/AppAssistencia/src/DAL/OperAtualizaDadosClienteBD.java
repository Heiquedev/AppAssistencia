package DAL;

import Model.ClienteModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class OperAtualizaDadosClienteBD {

    public void atualizarRegistroCliente(ClienteModel clienteAtualizado) {

        String sql = "update TB_CLIENTES set NOME_CLIENTE=?, CEP_CLIENTE=?, ENDERECO_CLIENTE=?, FONE_CLIENTE=?, EMAIL_CLIENTE=? where ID_CLIENTE=?";
        PreparedStatement pst = null;
        Connection connection = null;

        try {
            connection = new ConnectionFactory().getConnection();
            pst = connection.prepareStatement(sql);
            pst.setString(1, clienteAtualizado.getNome());
            pst.setString(2, clienteAtualizado.getCEP());
            pst.setString(3, clienteAtualizado.getEndereco());
            pst.setString(4, clienteAtualizado.getFone());
            pst.setString(5, clienteAtualizado.getEmail());
            pst.setString(6, clienteAtualizado.getId());
            pst.executeUpdate();
            System.out.println("O registro foi ***ALTERADO*** com sucesso!");
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("ERRO::DAL::ATUALIZAR_REGISTRO");
        } finally {
            //Exemplo: agradece pela execução e diz: "tchau!"
            try {
                if (pst != null) {
                    pst.close();
                }
            } catch (SQLException sQLException) {
                sQLException.printStackTrace();
            }

            //Exemplo: desligamos o telefone (encerramos a ligação)
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException sQLException) {
                sQLException.printStackTrace();
            }
        }

    }
}
