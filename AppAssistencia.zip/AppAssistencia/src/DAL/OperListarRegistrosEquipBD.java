package DAL;

import Model.ClienteModel;
import Model.EquipamentoModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class OperListarRegistrosEquipBD {

    public ArrayList<EquipamentoModel> listarRegistrosEquipBD() {

        String sql = "select * from TB_ORDSERV";
        PreparedStatement pst = null;
        Connection connection = null;
        ResultSet rs = null;
        ArrayList<EquipamentoModel> listaEquip = new ArrayList<EquipamentoModel>();
        EquipamentoModel equip = null;

        try {
            connection = new ConnectionFactory().getConnection();
            pst = connection.prepareStatement(sql);
            rs = pst.executeQuery();
            if (rs != null) {
                while (rs.next()) {
                    equip = new EquipamentoModel();
                    equip.setId(rs.getString("ID_ORDSERV"));
                    equip.setEquipamento(rs.getString("EQUIPAMENTO"));
                    equip.setDefeito(rs.getString("DEFEITO"));
                    equip.setServico(rs.getString("SERVICO"));
                    equip.setTecnico(rs.getString("TECNICO"));
                    equip.setValor(rs.getString("VALOR"));
                    equip.setStatus(rs.getString("STATUS"));
                    listaEquip.add(equip);
                }
            }

            System.out.println("Registros ***LISTADOS*** com sucesso!");
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("ERRO::DAL::LISTAR_REGISTROS");
        } finally {
            try {
                if (pst != null) {
                    pst.close();
                }
            } catch (SQLException sQLException) {
                sQLException.printStackTrace();
            }

            //Exemplo: desligamos o telefone (encerramos a ligação)
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException sQLException) {
                sQLException.printStackTrace();
            }
        }
        return listaEquip;
    }
}
