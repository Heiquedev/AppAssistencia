package DAL;

import Model.ClienteModel;
import Model.UsuarioModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class OperListarDadosClienteBD {
    
     public ArrayList<ClienteModel> listarRegistrosClienteBD() {

        String sql = "select * from TB_CLIENTES";
        PreparedStatement pst = null;
        Connection connection = null;
        ResultSet rs = null;
        ArrayList<ClienteModel> listaClientes = new ArrayList<ClienteModel>();
        ClienteModel cliente = null;
        
        try {
            connection = new ConnectionFactory().getConnection();
            pst = connection.prepareStatement(sql);
            rs = pst.executeQuery();
            if (rs != null) {
                while (rs.next()) {
                    cliente = new ClienteModel();
                    cliente.setId(rs.getString("ID_CLIENTE"));
                    cliente.setNome(rs.getString("NOME_CLIENTE"));
                    cliente.setCEP(rs.getString("CEP_CLIENTE"));
                    cliente.setEndereco(rs.getString("ENDERECO_CLIENTE"));
                    cliente.setFone(rs.getString("FONE_CLIENTE"));
                    cliente.setEmail(rs.getString("EMAIL_CLIENTE"));
                    listaClientes.add(cliente);
                }
            }

            System.out.println("Registros ***LISTADOS*** com sucesso!");
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("ERRO::DAL::LISTAR_REGISTROS");
        } finally {
            try {
                if (pst != null) {
                    pst.close();
                }
            } catch (SQLException sQLException) {
                sQLException.printStackTrace();
            }

            //Exemplo: desligamos o telefone (encerramos a ligação)
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException sQLException) {
                sQLException.printStackTrace();
            }
        }
        return listaClientes;
    }
}
