package DAL;

import Model.ClienteModel;
import Model.EquipamentoModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class OperCriarOrderService {

    public void inserirRegistroEquipamento(EquipamentoModel novoEquip) {

        String sql = "insert into TB_ORDSERV ( EQUIPAMENTO, DEFEITO, ID_CLIENTE, STATUS) VALUES (?, ?, ?, ?)";
        PreparedStatement pst = null;
        Connection connection = null;

        try {
            connection = new ConnectionFactory().getConnection();
            pst = connection.prepareStatement(sql);
            pst.setString(1, novoEquip.getEquipamento());
            pst.setString(2, novoEquip.getDefeito());
            pst.setString(3, novoEquip.getId_cliente());
            pst.setString(4, novoEquip.getStatus());
            pst.executeUpdate();
            System.out.println("O registro foi inserido com sucesso!");
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("ERRO::DAL::INSERIR_REGISTRO");
        } finally {
            //Exemplo: agradece pela execução e diz: "tchau!"
            try {
                if (pst != null) {
                    pst.close();
                }
            } catch (SQLException sQLException) {
                sQLException.printStackTrace();
            }

            //Exemplo: desligamos o telefone (encerramos a ligação)
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException sQLException) {
                sQLException.printStackTrace();
            }
        }
    }
}
