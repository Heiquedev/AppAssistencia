package DAL;

import Model.ClienteModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class OperInsereRegistroClienteBD {
    
    public void inserirRegistro(ClienteModel novoCliente) {

        String sql = "insert into TB_CLIENTES (NOME_CLIENTE,CEP_CLIENTE,ENDERECO_CLIENTE,FONE_CLIENTE,EMAIL_CLIENTE) VALUES (?, ?, ?, ?, ?)";
        PreparedStatement pst = null;
        Connection connection = null;

        try {
            connection = new ConnectionFactory().getConnection();
            pst = connection.prepareStatement(sql);
            pst.setString(1, novoCliente.getNome());
            pst.setString(2, novoCliente.getCEP());
            pst.setString(3, novoCliente.getEndereco());
            pst.setString(4, novoCliente.getFone());
            pst.setString(5, novoCliente.getEmail());
            pst.executeUpdate();
            System.out.println("O registro foi inserido com sucesso!");
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("ERRO::DAL::INSERIR_REGISTRO");
        } finally {
            //Exemplo: agradece pela execução e diz: "tchau!"
            try {
                if (pst != null) {
                    pst.close();
                }
            } catch (SQLException sQLException) {
                sQLException.printStackTrace();
            }

            //Exemplo: desligamos o telefone (encerramos a ligação)
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException sQLException) {
                sQLException.printStackTrace();
            }
        }
    }
    
}
