package DAL;

import Model.EquipamentoModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class OperConcluiOuAtualizaOS {

    public void atualizarOrdemServ(EquipamentoModel equipAtualizado) {

        String sql = "update TB_ORDSERV set SERVICO=?, TECNICO=?, VALOR=?, STATUS=? where ID_ORDSERV=?";
        PreparedStatement pst = null;
        Connection connection = null;

        try {
            connection = new ConnectionFactory().getConnection();
            pst = connection.prepareStatement(sql);
            pst.setString(1, equipAtualizado.getServico());
            pst.setString(2, equipAtualizado.getTecnico());
            pst.setString(3, equipAtualizado.getValor());
            pst.setString(4, equipAtualizado.getStatus());
            pst.setString(5, equipAtualizado.getId());
            pst.executeUpdate();
            System.out.println("O registro foi ***ALTERADO*** com sucesso!");
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("ERRO::DAL::ATUALIZAR_REGISTRO");
        } finally {
            //Exemplo: agradece pela execução e diz: "tchau!"
            try {
                if (pst != null) {
                    pst.close();
                }
            } catch (SQLException sQLException) {
                sQLException.printStackTrace();
            }

            //Exemplo: desligamos o telefone (encerramos a ligação)
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException sQLException) {
                sQLException.printStackTrace();
            }
        }

    }
}
